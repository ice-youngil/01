import React from 'react';
import 'assets/css/ToolSettings.css'; // CSS 파일을 import

const ToolSettings = ({
  selectedTool,
  toolSize,
  setToolSize,
  selectedColor,
  setSelectedColor,
  eraserSize,
  setEraserSize,
}) => {
  return (    
    <div>
      {selectedTool === 'pen' && (
        <div className="pen-settings-picker">
          <input 
            type="range" 
            min="1" 
            max="20" 
            value={toolSize} 
            onChange={(e) => setToolSize(Number(e.target.value))}  // 문자열을 숫자로 변환하여 상태 설정
            className="tool-size-slider" 
          />
          <div className="color-picker-container">
            <label>색상</label>
            <input 
              type="color" 
              value={selectedColor} 
              onChange={(e) => setSelectedColor(e.target.value)} 
            />
          </div>
        </div>
      )}

      {selectedTool === 'eraser' && (
        <div className="eraser-settings-picker">
          <input 
            type="range" 
            min="1" 
            max="70" 
            value={eraserSize} 
            onChange={(e) => setEraserSize(Number(e.target.value))}  // 문자열을 숫자로 변환하여 상태 설정
            className="tool-size-slider" 
          />
        </div>
      )}
    </div>
  );
};

export default ToolSettings;
