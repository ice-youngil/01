import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import SidebarButton from 'components/SidebarButton';
import CanvasComponent from './CanvasComponent';
import ToolSettings from 'components/ToolSettings';
import ShapeSelectionModal from 'services/threeD/ShapeSelectionModal';
import ThreeDModal from 'services/threeD/ThreeDModel';
import 'assets/css/SketchToolHome.css';

import textButtonIcon from 'assets/images/text.png';
import eraserButtonIcon from 'assets/images/eraser.png';
import elementButtonIcon from 'assets/images/element.png';
import penButtonIcon from 'assets/images/pen.png';
import backButtonIcon from 'assets/images/back.png';
import handIcon from 'assets/images/hand.png';

import html2canvas from "html2canvas";
import saveAs from "file-saver";

const SketchToolHome = () => {
  const navigate = useNavigate();
  const [selectedTool, setSelectedTool] = useState('pen');
  const [image, setImage] = useState(null);
  const [history, setHistory] = useState([]);
  const [currentStep, setCurrentStep] = useState(-1);
  const [toolSize, setToolSize] = useState(5);
  const [eraserSize, setEraserSize] = useState(10);
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [isModalOpen, setIsModalOpen] = useState(false); 
  const [is3DModalOpen, setIs3DModalOpen] = useState(false); 
  const [selectedShape, setSelectedShape] = useState(null); 
  const [emoji, setEmoji] = useState(null);
  const [textSettings, setTextSettings] = useState({
    fontSize: 16,
    color: '#000000',
    fontFamily: 'Arial',
  });
  const [isAltPressed, setIsAltPressed] = useState(false);
  const screenShotRef = useRef(null);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target.result);
        saveHistory(e.target.result);
        setToolSize(5);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveImage = async() => {
    if (!screenShotRef.current) return;

    try {
      const div = screenShotRef.current;
      const canvas = await html2canvas(div, { scale: 2 });
      canvas.toBlob((blob) => {
        if (blob !== null) {
          saveAs(blob, "result.png");
        }
      });
    } catch (error) {
      console.error("Error converting div to image:", error);
    }
  };

  const handleApplyModel = () => {
    if (image) {
      setIsModalOpen(true);
    } else {
      alert('이미지를 먼저 업로드해주세요.');
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setIs3DModalOpen(false);
  };

  const handleSelectShape = (shape) => {
    setSelectedShape(shape);
    setIsModalOpen(false);
    setIs3DModalOpen(true);
  };

  const saveHistory = (image) => {
    setHistory((prevHistory) => [...prevHistory.slice(0, currentStep + 1), image]);
    setCurrentStep((prevStep) => prevStep + 1);
  };

  const handleUndo = () => {
    if (currentStep > 0) {
      setCurrentStep((prevStep) => prevStep - 1);
      setImage(history[currentStep - 1]);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Alt') {
      setIsAltPressed(true);
    }
  };

  const handleKeyUp = (event) => {
    if (event.key === 'Alt') {
      setIsAltPressed(false);
    }
  };

  useEffect(() => {
    const htmlTitle = document.querySelector('title');
    htmlTitle.innerHTML = "영일도방 스케치 툴"
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return (
    <div className="sketchtoolhome-container">
      <div className="top-bar">
        <button className="back-button" onClick={() => navigate('/')}>
          <span>&lt;</span>
        </button>
        <button className="home-button">
          <span>홈</span>
        </button>
        <div className="separator"></div>
        <div className="load-sketch-button">
          <label>
            <span>스케치<br />불러오기</span>
            <input type="file" onChange={handleImageUpload} />
          </label>
        </div>
        <button className="save-button" onClick={handleSaveImage}>
          저장하기
        </button>
        <button className="apply-button" onClick={handleApplyModel}>
          적용하기
        </button>
      </div>
      <div ref={screenShotRef}>
        <CanvasComponent
          selectedTool={selectedTool}
          toolSize={toolSize}
          eraserSize={eraserSize}
          image={image}
          onSaveHistory={saveHistory}
          isAltPressed={isAltPressed}
          selectedColor={selectedColor}
        />
      </div>
      <div className="sidebar-buttons">
        <SidebarButton icon={textButtonIcon} label="텍스트" onClick={() => setSelectedTool('text')} />
        <SidebarButton icon={eraserButtonIcon} label="지우개" onClick={() => setSelectedTool('eraser')} />
        <SidebarButton icon={elementButtonIcon} label="요소" onClick={() => setSelectedTool('element')} />
        <SidebarButton icon={penButtonIcon} label="펜" onClick={() => setSelectedTool('pen')} />
        <SidebarButton icon={backButtonIcon} label="되돌리기" onClick={handleUndo} />
        <SidebarButton icon={handIcon} onClick={() => setSelectedTool('hand')} />
      </div>
      <ToolSettings
        selectedTool={selectedTool}
        textSettings={textSettings}
        handleTextSettingsChange={(key, value) => setTextSettings({ ...textSettings, [key]: value })}
        handleTextSettingsApply={() => {}}
        toolSize={toolSize}
        setToolSize={setToolSize}
        selectedColor={selectedColor}
        setSelectedColor={setSelectedColor}
        eraserSize={eraserSize}
        setEraserSize={setEraserSize}
        setEmoji={setEmoji}
      />
      <ShapeSelectionModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSelectShape={handleSelectShape}
      />
      <ThreeDModal
        isOpen={is3DModalOpen}
        onClose={handleCloseModal}
        image={image}
        shape={selectedShape}
      />
    </div>
  );
};

export default SketchToolHome;
