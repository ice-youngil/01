import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SidebarButton from '../components/SidebarButton';
import CanvasComponent from './CanvasComponent';
import ToolSettings from './ToolSettings';
import './SketchToolHome.css';
import textButtonIcon from '../assets/images/text.png';
import eraserButtonIcon from '../assets/images/eraser.png';
import elementButtonIcon from '../assets/images/element.png';
import penButtonIcon from '../assets/images/pen.png';
import designButtonIcon from '../assets/images/design.png';
import backButtonIcon from '../assets/images/back.png';
import handIcon from '../assets/images/hand.png';

const SketchToolHome = () => {
  const navigate = useNavigate();
  const canvasRef = useRef(null);
  const [selectedTool, setSelectedTool] = useState('pen');
  const [image, setImage] = useState(null);
  const [toolSize, setToolSize] = useState(5);
  const [eraserSize, setEraserSize] = useState(10);
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [history, setHistory] = useState([]);
  const [currentStep, setCurrentStep] = useState(-1);
  const [textSettings, setTextSettings] = useState({
    fontSize: 16,
    color: '#000000',
    fontFamily: 'Arial',
  });

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target.result);
        saveHistory();
        setToolSize(5);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveImage = () => {
    if (canvasRef.current) {
      const dataURL = canvasRef.current.getMergedImage();
      const link = document.createElement('a');
      link.download = 'sketch.png';
      link.href = dataURL;
      link.click();
    }
  };

  const handleApplyModel = () => {
    if (image) {
      const dataUrl = canvasRef.current.getMergedImage();
      navigate('/model', { state: { image: dataUrl } });
    } else {
      alert('이미지를 먼저 업로드해주세요.');
    }
  };

  const saveHistory = () => {
    if (canvasRef.current) {
      const dataUrl = canvasRef.current.getMergedImage();
      setHistory((prevHistory) => [...prevHistory.slice(0, currentStep + 1), dataUrl]);
      setCurrentStep((prevStep) => prevStep + 1);
    }
  };

  const handleUndo = () => {
    if (currentStep > 0) {
      setCurrentStep((prevStep) => prevStep - 1);
      const previousImage = history[currentStep - 1];
      setImage(previousImage);
      // 캔버스를 업데이트하는 로직 추가 필요
    }
  };

  const handleTextSettingsChange = (key, value) => {
    setTextSettings((prevSettings) => ({
      ...prevSettings,
      [key]: value,
    }));
  };

  const handleTextSettingsApply = () => {
    // 텍스트 설정 적용 로직 추가 가능
    console.log('Text settings applied:', textSettings);
  };

  return (
    <div className="sketch-tool-home">
      <div className="top-bar">
        <button className="back-button" onClick={() => navigate('/')}>
          <span>&lt;</span>
        </button>
        <button className="home-button">
          <span>홈</span>
        </button>
        <div className="separator"></div>
        <div className="load-sketch-button">
          <label>
            <span>스케치<br />불러오기</span>
            <input type="file" onChange={handleImageUpload} />
          </label>
        </div>
        <button className="save-button" onClick={handleSaveImage}>
          저장하기
        </button>
        <button className="apply-button" onClick={handleApplyModel}>
          적용하기
        </button>
      </div>
      <div className="sidebar-buttons">
        <SidebarButton icon={textButtonIcon} label="텍스트" onClick={() => setSelectedTool('text')} />
        <SidebarButton icon={eraserButtonIcon} label="지우개" onClick={() => setSelectedTool('eraser')} />
        <SidebarButton icon={elementButtonIcon} label="요소" onClick={() => setSelectedTool('element')} />
        <SidebarButton icon={penButtonIcon} label="펜" onClick={() => setSelectedTool('pen')} />
        <SidebarButton icon={designButtonIcon} label="문패지정" onClick={() => setSelectedTool('design')} />
        <SidebarButton icon={backButtonIcon} label="되돌리기" onClick={handleUndo} />
        <SidebarButton icon={handIcon} onClick={() => setSelectedTool('hand')} />
      </div>
      <ToolSettings
        selectedTool={selectedTool}
        textSettings={textSettings}
        handleTextSettingsChange={handleTextSettingsChange}
        handleTextSettingsApply={handleTextSettingsApply}
        toolSize={toolSize}
        setToolSize={setToolSize}
        selectedColor={selectedColor}
        setSelectedColor={setSelectedColor}
        eraserSize={eraserSize}
        setEraserSize={setEraserSize}
      />
      <CanvasComponent
        ref={canvasRef}
        selectedTool={selectedTool}
        toolSize={toolSize}
        eraserSize={eraserSize}
        image={image}
        onSaveHistory={saveHistory}
        selectedColor={selectedColor}
      />
    </div>
  );
};

export default SketchToolHome;
