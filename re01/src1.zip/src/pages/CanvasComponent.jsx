import React, { useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import './SketchToolHome.css';

// CanvasComponent는 캔버스 위에서 그림을 그릴 수 있는 기능을 제공하는 React 함수형 컴포넌트입니다.
// 다양한 도구를 사용하여 그리기, 캔버스 이동 및 확대/축소 기능을 지원하며, 그린 이미지를 저장할 수 있습니다.

const CanvasComponent = forwardRef(({ selectedTool, toolSize, eraserSize, image, onSaveHistory, selectedColor, textSettings }, ref) => {
  const canvasRef = useRef(null);  // 배경 캔버스(이미지 캔버스)에 대한 참조
  const drawingCanvasRef = useRef(null);  // 그리기 캔버스에 대한 참조
  const drawingContextRef = useRef(null);  // 그리기 컨텍스트에 대한 참조
  const [isDrawing, setIsDrawing] = useState(false);  // 사용자가 그림을 그리는 중인지 여부를 추적하는 상태
  const [isPanning, setIsPanning] = useState(false);  // 사용자가 캔버스를 이동 중인지 여부를 추적하는 상태
  const [startX, setStartX] = useState(0);  // 캔버스 이동을 위한 초기 X 좌표
  const [startY, setStartY] = useState(0);  // 캔버스 이동을 위한 초기 Y 좌표
  const [offsetX, setOffsetX] = useState(0);  // 캔버스 이동을 위한 X 오프셋
  const [offsetY, setOffsetY] = useState(0);  // 캔버스 이동을 위한 Y 오프셋
  const [scale, setScale] = useState(1);  // 캔버스 확대/축소 비율을 추적하는 상태
  const [textBoxes, setTextBoxes] = useState([]);  // 텍스트 상자 상태

  // 부모 컴포넌트가 ref를 통해 getMergedImage 함수를 사용할 수 있도록 설정
  useImperativeHandle(ref, () => ({
    getMergedImage: () => {
      const canvas = canvasRef.current;
      const drawingCanvas = drawingCanvasRef.current;
      const mergedCanvas = document.createElement('canvas');
      const mergedContext = mergedCanvas.getContext('2d');

      mergedCanvas.width = canvas.width;
      mergedCanvas.height = canvas.height;

      // 배경 이미지를 그리기
      mergedContext.drawImage(canvas, 0, 0);

      // 그리기 캔버스를 그 위에 덮어쓰기
      mergedContext.drawImage(drawingCanvas, 0, 0);

      // 텍스트 상자를 그리기
      textBoxes.forEach(textBox => {
        mergedContext.font = `${textBox.fontSize}px ${textBox.fontFamily}`;
        mergedContext.fillStyle = textBox.color;
        mergedContext.fillText(textBox.text, textBox.x, textBox.y);
      });

      // 합쳐진 이미지를 데이터 URL 형식으로 반환
      return mergedCanvas.toDataURL('image/png');
    }
  }));

  useEffect(() => {
    const drawingCanvas = drawingCanvasRef.current;
    const drawingContext = drawingCanvas.getContext('2d');
    drawingContext.lineCap = 'round';  // 그리기 선의 끝 모양을 둥글게 설정
    drawingContextRef.current = drawingContext;

    const canvasContainer = document.querySelector('.canvas-container');

    if (image) {
      canvasContainer.style.position = 'relative';
      canvasContainer.style.overflow = 'hidden';
      canvasContainer.style.display = 'flex';
      canvasContainer.style.alignItems = 'center';
      canvasContainer.style.justifyContent = 'center';
    }

    canvasContainer.addEventListener('wheel', handleWheel);
    canvasContainer.addEventListener('mousedown', startPanning);
    canvasContainer.addEventListener('mousemove', pan);
    canvasContainer.addEventListener('mouseup', stopPanning);

    return () => {
      canvasContainer.removeEventListener('wheel', handleWheel);
      canvasContainer.removeEventListener('mousedown', startPanning);
      canvasContainer.removeEventListener('mousemove', pan);
      canvasContainer.removeEventListener('mouseup', stopPanning);
    };
  }, [scale, toolSize, offsetX, offsetY, selectedTool, image]);

  // 마우스 휠을 사용해 캔버스를 확대/축소하는 함수
  const handleWheel = (event) => {
    if (event.altKey) {
      event.preventDefault();
      const newScale = Math.min(Math.max(0.5, scale + event.deltaY * -0.001), 3);
      setScale(newScale);
      const canvas = canvasRef.current;
      const drawingCanvas = drawingCanvasRef.current;
      canvas.style.transform = `scale(${newScale}) translate(${offsetX}px, ${offsetY}px)`;
      drawingCanvas.style.transform = `scale(${newScale}) translate(${offsetX}px, ${offsetY}px)`;
    }
  };

  // 패닝(이동) 시작 시 호출되는 함수
  const startPanning = (event) => {
    if (selectedTool === 'hand') {
      setIsPanning(true);  // 패닝 시작을 표시
      setStartX(event.clientX);  // 패닝 시작 위치 X 좌표 저장
      setStartY(event.clientY);  // 패닝 시작 위치 Y 좌표 저장
    }
  };

  // 패닝 중 호출되는 함수, 마우스 이동에 따라 캔버스를 이동시킴
  const pan = (event) => {
    if (isPanning) {
      const dx = (event.clientX - startX) * 1.2;  // 패닝 중 이동한 X 좌표
      const dy = (event.clientY - startY) * 1.2;  // 패닝 중 이동한 Y 좌표
      setOffsetX((prevOffsetX) => prevOffsetX + dx);  // X 오프셋 업데이트
      setOffsetY((prevOffsetY) => prevOffsetY + dy);  // Y 오프셋 업데이트
      const canvas = canvasRef.current;
      canvas.style.transform = `scale(${scale}) translate(${offsetX + dx}px, ${offsetY + dy}px)`;  // 캔버스 이동 적용
      setStartX(event.clientX);  // 시작 X 좌표 업데이트
      setStartY(event.clientY);  // 시작 Y 좌표 업데이트
    }
  };

  // 패닝(이동) 종료 시 호출되는 함수
  const stopPanning = () => {
    setIsPanning(false);  // 패닝 종료를 표시
  };

  // 좌표를 조정하는 함수
  const adjustCoordinates = (nativeEvent) => {
    const canvas = drawingCanvasRef.current;
    const rect = canvas.getBoundingClientRect();
    return {
      offsetX: (nativeEvent.clientX - rect.left) * (canvas.width / rect.width),
      offsetY: (nativeEvent.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  // 그림 그리기를 시작할 때 호출되는 함수
  const startDrawing = ({ nativeEvent }) => {
    if (selectedTool !== 'hand') {
      const { offsetX, offsetY } = adjustCoordinates(nativeEvent);
      drawingContextRef.current.beginPath();
      drawingContextRef.current.moveTo(offsetX, offsetY);
      setIsDrawing(true);
    }
  };

  // 그림 그리기를 종료할 때 호출되는 함수
  const finishDrawing = () => {
    if (selectedTool !== 'hand') {
      drawingContextRef.current.closePath();
      setIsDrawing(false);
      onSaveHistory(drawingCanvasRef.current);
    }
  };

  // 그림 그리는 도중에 마우스를 이동할 때 호출되는 함수
  const draw = ({ nativeEvent }) => {
    if (isDrawing && selectedTool !== 'hand') {
      const { offsetX, offsetY } = adjustCoordinates(nativeEvent);
      drawingContextRef.current.lineTo(offsetX, offsetY);
      drawingContextRef.current.stroke();
    }
  };

  // 캔버스에서 클릭할 때 텍스트 상자를 생성하는 함수
  const handleCanvasClick = (e) => {
    if (selectedTool === 'text') {
      const rect = drawingCanvasRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const newTextBox = {
        x,
        y,
        text: '텍스트를 입력하세요',
        fontSize: textSettings.fontSize,
        color: textSettings.color,
        fontFamily: textSettings.fontFamily,
      };
      setTextBoxes([...textBoxes, newTextBox]);
    }
  };

  // 이미지가 변경될 때마다 캔버스에 이미지를 그리는 useEffect 훅
  useEffect(() => {
    if (image) {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      const img = new Image();
      img.src = image;
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.drawImage(img, 0, 0, canvas.width, canvas.height);

        const drawingCanvas = drawingCanvasRef.current;
        drawingCanvas.width = img.width;
        drawingCanvas.height = img.height;
      };
    }
  }, [image]);

  return (
    <div className="canvas-container" onClick={handleCanvasClick}>
      <canvas ref={canvasRef} className={image ? 'active-canvas' : 'inactive-canvas'} />
      <canvas
        ref={drawingCanvasRef}
        onMouseDown={startDrawing}
        onMouseUp={finishDrawing}
        onMouseMove={draw}
        className={image ? 'active-canvas' : 'inactive-canvas'}
      />
      {textBoxes.map((textBox, index) => (
        <div
          key={index}
          contentEditable
          style={{
            position: 'absolute',
            top: textBox.y,
            left: textBox.x,
            fontSize: textBox.fontSize,
            color: textBox.color,
            fontFamily: textBox.fontFamily,
            whiteSpace: 'nowrap',
          }}
          onBlur={(e) => {
            const updatedTextBoxes = [...textBoxes];
            updatedTextBoxes[index].text = e.target.innerText;
            setTextBoxes(updatedTextBoxes);
          }}
        >
          {textBox.text}
        </div>
      ))}
      {!image && <div className="placeholder">이미지를 불러와 주세요</div>}
    </div>
  );
});

export default CanvasComponent;
